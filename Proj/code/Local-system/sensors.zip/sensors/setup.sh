insmod distance.ko
echo "23 24 3000" > /sys/class/distance-sensor/configure
