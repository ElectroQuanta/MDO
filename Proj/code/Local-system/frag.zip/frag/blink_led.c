#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

void simpleDelay (void)
{
    volatile unsigned int i;
    for (i = 0; i != 100000000; i++);
}	

int main(void)
{
    sleep(2);
    printf("Devicer Drivers - frag Blinking\n");

    unsigned int count = 0;
    printf("\n");

    printf("\n\nInserting Device Driver...\n");
    system("insmod /etc/frag.ko");

    printf("\nCheck devicer driver:\n");
    system("lsmod");

    printf("\nIs the device driver in /dev:\n");
    system("ls -l /dev/frag0");
    sleep(3);

    int fd0 = open("/dev/frag0", O_WRONLY);
    char fragOn = '1', fragOff = '0';

    sleep(1);
    printf("\nStart!! Space stopsafter the off...");
    char c = getchar();
    while(c != 0x20) //space
    {
        
        write(fd0, &fragOn, 1);
        printf("\non!");

        getchar();
        write(fd0, &fragOff, 1);
        printf("\noff!");

        c = getchar();
    }
    printf("Closing Device Driver.\n");
    close(fd0);
    putchar('\n');
    printf("Removing Device Driver.\n");
    system("rmmod frag");

    return 0;

}
