
#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>

void simple_fork(){
    // make two process which run same 
    // program after this instruction 
    fork();
    printf("Hello world!\n"); 
}

void PID_fork(){
    // make two process which run same 
    // program after this instruction 
    fork();
    int pid = getpid(); 
    printf("Hello world! - PID: %d\n",pid); 
}

void parents_fork(){
    // make two process which run same 
    // program after this instruction 
    fork();
    fork(); 
    fork(); 
    int pid = getpid(); 
    printf("Hello world! - PID: %d\n",pid); 

//        L1        // There will be 1 child process 
//     /      \     // created by line 1.
//   L2       L2    // There will be 2 child processes
//  /  \     /  \   //  created by line 2
// L3  L3   L3  L3  // There will be 4 child processes 
                    // created by line 3
}

void parents2_fork(){
    // make two process which run same 
    // program after this instruction 
    int level; 
    fork();
    fork(); 
    level = fork(); 
    int pid = getpid(); 
    printf("Hello world: %d! - Level: %d\n",pid,level); 
}

void set_id(){
    if(fork() != 0)
    	exit(EXIT_SUCCESS);
    setsid();
    int pid = getpid(); 
    int sid = getsid(pid); 
    printf("Hello world: %d! - SID: %d\n",pid,sid); 
}

int main(){ 
  	//simple_fork();
	//PID_fork();
	//parents_fork();
	parents2_fork();
   	//set_id();
    	return 0; 
}





