#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int main(){
    int file = open("/dev/memory", O_RDWR);
    char write_buf[128], read_buf[128];

    if(file < 0){
        printf("Erro a aceder ao device driver.\n");
        return 0;
    }

    printf("Introduza texto: ");

    scanf("%s", write_buf);

    write(file, write_buf, strlen(write_buf));

    while(read(file, read_buf, strlen(read_buf)) == 0); //0 indica EOF
    printf("O ultimo caractere: %s\n", read_buf);

    return 0;
}